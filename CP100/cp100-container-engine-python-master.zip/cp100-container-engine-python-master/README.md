# cp100-container-engine-python
Used in the CP100 course. 

A YAML resource file used to create a Kubernetes pod on Container Engine. 

The pod is configured to use to containers; a front end Python server using Flask and a Redis backend.
