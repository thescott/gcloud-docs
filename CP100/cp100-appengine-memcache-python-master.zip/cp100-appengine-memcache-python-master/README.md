# cp100-appengine-memcache-python
Used in the CP100 course - A simple Guestbook application to demonstrate getting started with App Engine.
