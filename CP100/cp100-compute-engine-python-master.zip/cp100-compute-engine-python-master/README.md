# cp100-compute-engine
Used in the CP100 course. 

A simple container to demonstrate deploying an application to Compute Engine

Adapted and based on work at https://github.com/GoogleCloudPlatform/container-vm-guestbook-redis-python
