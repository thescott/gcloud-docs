# cp100-appengine-datastore-java
Used in the CP100 course - Guestbook, An App Engine Java application that demonstrates use of Google Cloud Datastore
