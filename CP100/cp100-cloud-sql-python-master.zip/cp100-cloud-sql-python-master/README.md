# cp100-cloud-sql-python
Used in the CP100 course - A sample container application written in Python to demonstrate connection from Compute Engine to a Cloud SQL instance.
