# cp100-appengine-datastore-python
Used in the CP100 course - Guestbook, An App Engine Python application that demonstrates use of Google Cloud Datastore
