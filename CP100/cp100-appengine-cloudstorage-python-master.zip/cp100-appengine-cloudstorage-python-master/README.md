# cp100-appengine-cloudstorage-python
Used in the CP100 course. 

A Python App Engine application that demonstrates usage of the Google Cloud Storage API

Also includes a copy of the client, the latest version of which can be found at https://github.com/GoogleCloudPlatform/appengine-gcs-client
