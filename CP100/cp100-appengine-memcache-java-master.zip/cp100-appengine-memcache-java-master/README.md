# cp100-appengine-memcache-java
Used in the CP100 course - An App Engine application that demonstrates Memcache API
