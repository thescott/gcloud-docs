# cp100-cloud-sql-java
Used in the CP100 course - A simple container to demonstrate deploying a Java Web Application on Compute Engine that communicates to a Cloud SQL instance
